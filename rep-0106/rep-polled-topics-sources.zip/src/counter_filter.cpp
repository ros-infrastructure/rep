/*
 * custom_filter.cpp
 */

#include "custom_ros/counter_filter.h"
#include "custom_ros/filter_factory.h"

#include <ros/ros.h>

#include <sstream>

ros::GenericFilter* createCustomFilter()
{
  return new custom_ros::CounterFilter();
}

namespace custom_ros
{

CounterFilter::CounterFilter()
{}

//CustomFilter::CustomFilter(const CustomFilter& rhs)
//  : GenericFilter(rhs)
//{
//  ROS_ERROR("CustomFilter(const CustomFilter& rhs)");
//  passNumber_ = rhs.passNumber_;
//  passCounter_ = rhs.passCounter_;
//}

CounterFilter::CounterFilter(const std::string& nodeName, int passNumber)
  : passNumber_(passNumber)
  , passCounter_(0)
{
  filterType_ = "CounterFilter";
  nodeName_ = nodeName;
  if (passNumber_ < 1)
  {
    passNumber_ = 1;
  }
  std::stringstream ss;
  ss << passNumber_;
  ss >> config_;
}

CounterFilter::CounterFilter(const FilterDataConstPtr& filterData)
{
  filterType_ = filterData->filter_type;
  nodeName_ = filterData->node_name;
  std::string config = filterData->config;
  std::stringstream ss;
  ss << config;
  ss >> passNumber_;
}

//CounterFilter::CounterFilter(const std::string& messageString)
//  : GenericFilter(messageString)
//  , passNumber_(1)
//  , passCounter_(0)
//{
//  ROS_ERROR("CustomFilter(std::string messageString)");
//  std::size_t first_pos, second_pos;
//  first_pos = messageString.find(";");
//  second_pos = messageString.find(";", first_pos+1);
//  filterType_ = messageString.substr(0, first_pos);
//  nodeName_ = messageString.substr(first_pos+1, second_pos-first_pos-1);
//  std::string strNumber = messageString.substr(second_pos+1);
//  std::stringstream ss;
//  ss << strNumber;
//  ss >> passNumber_;
//}

//FilterData CounterFilter::getFilterData() const
//{
//  FilterData data;
//  data.filter_type = filterType_;
//  data.node_name = nodeName_;
//  data.config = config_;
//  return data;
//}

//std::string CounterFilter::createMessage() const
//{
//  std::stringstream ss;
//  ss << filterType_ << ";" << nodeName_ << ";" << passNumber_;
//  return ss.str();
//}

bool CounterFilter::passCurrentMessage()
{
  return (passCounter_++ % passNumber_ == 0);
}

void CounterFilter::init()
{
  FilterFactory::add("CustomFilter", createCustomFilter);
}

}

//REGISTER_FILTER(ros::GenericFilter, "CustomFilter");
