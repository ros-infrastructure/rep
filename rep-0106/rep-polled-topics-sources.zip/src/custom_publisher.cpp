/*
 * custom_publisher.cpp
 *
 *  Created on: Oct 6, 2010
 *      Author: markus
 */

#include "custom_ros/custom_publisher.h"
#include "custom_ros/filter_factory.h"

#include <ros/generic_filter.h>
#include <ros/node_handle.h>
#include <ros/topic_manager.h>
#include <ros/rate.h>

#include <std_msgs/Bool.h>
#include <std_msgs/Empty.h>

#include <sstream>

namespace custom_ros
{

CustomPublisher::CustomPublisher(const Publisher& rhs)
  : Publisher(rhs)
{
}

void CustomPublisher::setupFilter()
{
  ROS_WARN("[CustomPublisher] setupFilter()");

  std::string subscriberTopic = impl_->topic_ + "_updateFilter";
  //filterSubscriber_ = impl_->node_handle_->subscribe<std_msgs::String>(subscriberTopic, 10, &CustomPublisher::filterUpdateCallback, this);
  filterSubscriber_ = impl_->node_handle_->subscribe<FilterData>(subscriberTopic, 10, &CustomPublisher::filterUpdateCallback, this);

  std::string publisherTopic = impl_->topic_ + "_newPublisher";
  filterPublisher_ = impl_->node_handle_->advertise<std_msgs::Empty>(publisherTopic, 1);

  ros::Rate loop_rate(2);
  loop_rate.sleep();
  std_msgs::Empty msg;
  filterPublisher_.publish(msg);
}

void CustomPublisher::filterUpdateCallback(const FilterDataConstPtr& msg)
{
  ROS_WARN("[CustomPublisher] filterUpdateCallback( %s;%s;%s )", msg->filter_type.c_str(), msg->node_name.c_str(), msg->config.c_str());
  //GenericFilterPtr filter(ros_filter::FilterFactory::createFilter(msg->data));
  GenericFilterPtr filter(FilterFactory::createFilter(msg));
  TopicManager::instance()->setGenericFilter(impl_->topic_, filter);
}

}
