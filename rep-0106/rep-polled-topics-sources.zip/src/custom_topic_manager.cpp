/*
 * custom_topic_manager.cpp
 *
 *  Created on: Oct 6, 2010
 *      Author: markus
 */

#include "custom_ros/custom_topic_manager.h"
#include "custom_ros/custom_publication.h"

#include <ros/publication.h>

namespace custom_ros
{

//void CustomTopicManager::setGenericFilter(const std::string &topic, GenericFilter* filter)
//{
//  boost::recursive_mutex::scoped_lock lock(advertised_topics_mutex_);
//  PublicationPtr p = lookupPublicationWithoutLock(topic);
//  p->setGenericFilter(filter);
//}

Publication* CustomTopicManager::createPublication(const std::string &name, const std::string &datatype, const std::string &_md5sum,
      const std::string& message_definition, size_t max_queue, bool latch, bool has_header)
{
  return new CustomPublication(name, datatype, _md5sum, message_definition, max_queue, latch, has_header);
}

}
