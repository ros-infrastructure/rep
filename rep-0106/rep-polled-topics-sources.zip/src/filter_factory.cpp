/*
 * filter_factory.cpp
 *
 *  Created on: Oct 14, 2010
 *      Author: markus
 */

#include "custom_ros/filter_factory.h"
#include "custom_ros/counter_filter.h"
#include "custom_ros/frequency_filter.h"
#include "custom_ros/pass_through_filter.h"

#include <iostream>

namespace custom_ros
{

std::map<std::string, GenericFilter* (*)()> FilterFactory::filter_map_;

GenericFilter* FilterFactory::createFilter(const FilterDataConstPtr& filterData)
{
  std::string type = filterData->filter_type;
  if (type == "PassThroughFilter")
  {
    return new PassThroughFilter(filterData);
  }
  else if(type == "CounterFilter")
  {
    return new CounterFilter(filterData);
  }
  else if(type == "FrequencyFilter")
  {
    return new FrequencyFilter(filterData);
  }

  return new PassThroughFilter();
}

GenericFilter* FilterFactory::createFilter(std::string config)
{
  //std::string name = GenericFilter::extractFilterType(config);

//  if(name == "CustomFilter")
//  {
//    return new CounterFilter(config);
//  }
//  else if(name == "FrequencyFilter")
//  {
//    return new FrequencyFilter(config);
//  }

  return new PassThroughFilter();

//  if (filter_map_.size() > 0 && filter_map_.find(name) == filter_map_.end())
//  {
//    return NULL;
//  }
//  return filter_map_[name]();
}

void FilterFactory::add(std::string name, GenericFilter* (*createFilter)())
{
  std::cout << "[FilterFactory] add( " << name << " )" << std::endl;
  if (filter_map_.count(name) == 0)
  {
    std::cout << "filter_map_.count(name) == 0" << std::endl;
  }
  else
  {
    std::cout << "else" << std::endl;
  }
  //GenericFilter* filter = createFilter();
  std::cout << "ros::GenericFilter* filter = createFilter();" << std::endl;
  //std::cout << "filter->createMessage(): " << filter->createMessage() << std::endl;
  filter_map_[name] = createFilter;
  std::cout << "filter_map_[name] = createFilter;" << std::endl;
}

}
