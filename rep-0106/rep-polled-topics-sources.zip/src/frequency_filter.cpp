/*
 * frequency_filter.cpp
 *
 *  Created on: Oct 15, 2010
 *      Author: markus
 */

#include "custom_ros/frequency_filter.h"
#include "custom_ros/filter_factory.h"

#include <ros/ros.h>

#include <sstream>

namespace custom_ros
{

FrequencyFilter::FrequencyFilter()
{}

FrequencyFilter::FrequencyFilter(const std::string& nodeName, double frequency)
  : frequency_(frequency)
  , cycle_(1.0 / frequency)
{
  filterType_ = "FrequencyFilter";
  nodeName_ = nodeName;
  std::stringstream ss;
  ss << frequency;
  ss >> config_;
}

FrequencyFilter::FrequencyFilter(const FilterDataConstPtr& filterData)
{
  filterType_ = filterData->filter_type;
  nodeName_ = filterData->node_name;
  std::string config = filterData->config;
  std::stringstream ss;
  ss << config;
  ss >> frequency_;
  cycle_ = Duration(1.0 / frequency_);
  start_ = Time::now();
}

//FrequencyFilter::FrequencyFilter(const std::string& messageString)
//  : GenericFilter(messageString)
//{
//  ROS_ERROR("FrequencyFilter(std::string messageString)");
//  std::size_t first_pos, second_pos;
//  first_pos = messageString.find(";");
//  second_pos = messageString.find(";", first_pos+1);
//  filterType_ = messageString.substr(0, first_pos);
//  nodeName_ = messageString.substr(first_pos+1, second_pos-first_pos-1);
//  std::string strNumber = messageString.substr(second_pos+1);
//  std::stringstream ss;
//  ss << strNumber;
//  ss >> frequency_;
//  cycle_ = Duration(1.0 / frequency_);
//  start_ = Time::now();
//}

//std::string FrequencyFilter::createMessage() const
//{
//  std::stringstream ss;
//  ss << filterType_ << ";" << nodeName_ << ";" << frequency_;
//  return ss.str();
//}

bool FrequencyFilter::passCurrentMessage()
{
  Time current_ = Time::now();
  if (current_ - start_ > cycle_)
  {
    start_ = current_;
    return true;
  }
  return false;
}

}
