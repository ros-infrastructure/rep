/*
 * custom_publication.cpp
 *
 *  Created on: Oct 6, 2010
 *      Author: markus
 */

#include "custom_ros/custom_publication.h"

#include <ros/subscriber_link.h>
#include <ros/connection.h>
#include <ros/callback_queue_interface.h>
#include <ros/single_subscriber_publisher.h>
#include <ros/serialization.h>
#include <roslib/Header.h>

namespace custom_ros
{

CustomPublication::CustomPublication(const std::string &name, const std::string &datatype, const std::string &_md5sum,
                                     const std::string& message_definition, size_t max_queue, bool latch, bool has_header)
  : Publication(name, datatype, _md5sum, message_definition, max_queue, latch, has_header)
{
}

bool CustomPublication::enqueueMessage(const SerializedMessage& m)
{
  boost::mutex::scoped_lock lock(subscriber_links_mutex_);
  if (dropped_)
  {
    return false;
  }

  ROS_ASSERT(m.buf);

  uint32_t seq = incrementSequence();
  if (has_header_)
  {
    // If we have a header, we know it's immediately after the message length
    // Deserialize it, write the sequence, and then serialize it again.
    namespace ser = ros::serialization;
    roslib::Header header;
    ser::IStream istream(m.buf.get() + 4, m.num_bytes - 4);
    ser::deserialize(istream, header);
    header.seq = seq;
    ser::OStream ostream(m.buf.get() + 4, m.num_bytes - 4);
    ser::serialize(ostream, header);
  }

//  if ((cnt % 2 == 0 && cnt < 20) || cnt % 3 == 0)
//  {
//    //ROS_WARN("%s %i: %i", name_, cnt, subscriber_links_.size());
//    ROS_WARN_STREAM(name_ << " " << cnt << ": " << subscriber_links_.size());
//  }
//  cnt++;

  for(V_SubscriberLink::iterator i = subscriber_links_.begin();
      i != subscriber_links_.end(); ++i)
  {
    const SubscriberLinkPtr& sub_link = (*i);
    if (this->passCurrentMessage(sub_link->getDestinationCallerID()))
    {
      sub_link->enqueueMessage(m, true, false);
    }
  }

  if (latch_)
  {
    last_message_ = m;
  }

  return true;
}

void CustomPublication::setGenericFilter(const GenericFilterPtr& filter)
{
  boost::mutex::scoped_lock lock(filter_mutex_);
  //ROS_INFO("[CustomPublication] setGenericFilter - %s", filter->createMessage().c_str());
  filterMap_[filter->getNodeName()] = filter;
}

bool CustomPublication::passCurrentMessage(const std::string& nodeName)
{
  boost::mutex::scoped_lock lock(filter_mutex_);
  if (filterMap_.count(nodeName) > 0)
  {
    GenericFilterPtr filter = filterMap_[nodeName];
    return filter->passCurrentMessage();
  }
  return true;
}

}
