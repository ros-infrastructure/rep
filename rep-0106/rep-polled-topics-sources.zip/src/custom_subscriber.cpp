/*
 * custom_subscriber.cpp
 *
 *  Created on: Oct 8, 2010
 *      Author: markus
 */

#include "custom_ros/custom_subscriber.h"
#include "custom_ros/FilterData.h"
#include "custom_ros/pass_through_filter.h"

#include <ros/node_handle.h>

//#include <std_msgs/String.h>

namespace custom_ros
{

CustomSubscriber::CustomSubscriber(const Subscriber& rhs)
  : Subscriber(rhs)
{
}

void CustomSubscriber::setupFilter()
{
  ROS_WARN("[CustomSubscriber] setupFilter() - %s", impl_->topic_.c_str());
  const std::string subscriberTopic = impl_->topic_ + "_newPublisher";
  filterSubscriber_ = impl_->node_handle_->subscribe<std_msgs::Empty>(subscriberTopic, 10, &CustomSubscriber::newPublisherCallback, this);

  const std::string publisherTopic = impl_->topic_ + "_updateFilter";
  //filterPublisher_ = impl_->node_handle_->advertise<std_msgs::String>(publisherTopic, 1);
  filterPublisher_ = impl_->node_handle_->advertise<FilterData>(publisherTopic, 1);

  filter_.reset(new PassThroughFilter());
}

void CustomSubscriber::setGenericFilter(const GenericFilterPtr& filter)
{
  //ROS_WARN("[CustomSubscriber] setCustomFilter( %s )", filter->createMessage().c_str());
  filter_ = filter;
  this->updatePublishers();
}

void CustomSubscriber::newPublisherCallback(const std_msgs::EmptyConstPtr& emptyMsg)
{
  ROS_WARN("[CustomSubscriber] newPublisherCallback()");
  this->updatePublishers();
}

void CustomSubscriber::updatePublishers()
{
  FilterData filter_data_msg;
  filter_data_msg.filter_type = filter_->getFilterType();
  filter_data_msg.node_name = filter_->getNodeName();
  filter_data_msg.config = filter_->getConfig();

  //std_msgs::String msg;
  //msg.data = filter_->createMessage();
  ROS_WARN("[CustomSubscriber] updatePublishers - %s", filter_->toString().c_str());
  filterPublisher_.publish(filter_data_msg);
}

}
