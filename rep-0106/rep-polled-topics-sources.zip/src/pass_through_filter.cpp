/*
 * pass_through_filter.cpp
 *
 *  Created on: Oct 16, 2010
 *      Author: markus
 */

#include "custom_ros/pass_through_filter.h"
#include "custom_ros/filter_factory.h"

#include <ros/ros.h>

#include <sstream>

namespace custom_ros
{

PassThroughFilter::PassThroughFilter()
{
  filterType_ = "PassThroughFilter";
  nodeName_ = "";
  config_ = "";
}

PassThroughFilter::PassThroughFilter(const std::string& nodeName)
{
  filterType_ = "PassThroughFilter";
  nodeName_ = nodeName;
  config_ = "";
}

PassThroughFilter::PassThroughFilter(const FilterDataConstPtr& filterData)
{
  filterType_ = filterData->filter_type;
  nodeName_ = filterData->node_name;
  config_ = filterData->config;
}

bool PassThroughFilter::passCurrentMessage()
{
  return true;
}

}
