/*
 * frequency_filter.h
 *
 *  Created on: Oct 15, 2010
 *      Author: markus
 */

#ifndef FREQUENCY_FILTER_H_
#define FREQUENCY_FILTER_H_

#include "custom_ros/FilterData.h"

#include <ros/generic_filter.h>
#include <ros/time.h>
#include <ros/duration.h>

#include <string>

using namespace ros;

namespace custom_ros
{

class FrequencyFilter : public GenericFilter
{
public:
  FrequencyFilter();

  FrequencyFilter(const std::string& nodeName, double frequency);

  FrequencyFilter(const FilterDataConstPtr& filterData);

  //FrequencyFilter(const std::string& messageString);

  //virtual ~CustomFilter();

  //virtual std::string createMessage() const;

  virtual bool passCurrentMessage();

private:
  double frequency_;

  Time start_;

  Duration cycle_;
};

}

#endif /* FREQUENCY_FILTER_H_ */
