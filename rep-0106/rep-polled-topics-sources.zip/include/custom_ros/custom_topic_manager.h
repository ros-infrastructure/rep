/*
 * custom_topic_manager.h
 *
 *  Created on: Oct 6, 2010
 *      Author: markus
 */

#ifndef CUSTOM_TOPIC_MANAGER_H_
#define CUSTOM_TOPIC_MANAGER_H_

#include <ros/topic_manager.h>
#include <ros/generic_filter.h>

using namespace ros;

namespace custom_ros
{

class CustomTopicManager : public TopicManager
{
public:
  //virtual void setGenericFilter(const std::string &topic, GenericFilter* filter);

  virtual Publication* createPublication(const std::string &name, const std::string &datatype, const std::string &_md5sum,
        const std::string& message_definition, size_t max_queue, bool latch, bool has_header);
};

}

#endif /* CUSTOM_TOPIC_MANAGER_H_ */
