/*
 * custom_subscriber.h
 *
 *  Created on: Oct 8, 2010
 *      Author: markus
 */

#ifndef CUSTOM_SUBSCRIBER_H_
#define CUSTOM_SUBSCRIBER_H_

#include <ros/publisher.h>
#include <ros/subscriber.h>
#include <ros/generic_filter.h>

#include <std_msgs/Empty.h>

using namespace ros;

namespace custom_ros
{

class CustomSubscriber : public Subscriber
{
public:
  CustomSubscriber(const Subscriber& rhs);

  virtual void setGenericFilter(const GenericFilterPtr& filter);

  virtual void setupFilter();

public:
  void newPublisherCallback(const std_msgs::EmptyConstPtr& msg);

  void updatePublishers();

  Subscriber filterSubscriber_;

  Publisher filterPublisher_;

  GenericFilterPtr filter_;
};

}

#endif /* CUSTOM_SUBSCRIBER_H_ */
