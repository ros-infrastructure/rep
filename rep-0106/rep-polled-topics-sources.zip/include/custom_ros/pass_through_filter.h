/*
 * pass_through_filter.h
 *
 *  Created on: Oct 16, 2010
 *      Author: markus
 */

#ifndef PASS_THROUGH_FILTER_H_
#define PASS_THROUGH_FILTER_H_

#include "custom_ros/FilterData.h"

#include <ros/generic_filter.h>

#include <string>

using namespace ros;

namespace custom_ros
{

class PassThroughFilter : public GenericFilter
{
public:
  PassThroughFilter();

  PassThroughFilter(const std::string& nodeName);

  PassThroughFilter(const FilterDataConstPtr& filterData);

  virtual bool passCurrentMessage();
};

}

#endif /* PASS_THROUGH_FILTER_H_ */
