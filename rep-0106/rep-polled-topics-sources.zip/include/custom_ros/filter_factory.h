/*
 * filter_factory.h
 *
 *  Created on: Oct 14, 2010
 *      Author: markus
 */

#ifndef FILTER_FACTORY_H_
#define FILTER_FACTORY_H_

#include "custom_ros/FilterData.h"

#include <ros/generic_filter.h>

#include <map>
#include <string>

using namespace ros;

namespace ros
{
  class GenericFilter;
}

namespace custom_ros
{

class FilterFactory
{

public:
  static GenericFilter* createFilter(std::string name);
  static GenericFilter* createFilter(const FilterDataConstPtr& filterData);

  static void add(std::string name, GenericFilter* (*createFilter)());

private:
  static std::map<std::string, GenericFilter* (*)()> filter_map_;
};

}

#define REGISTER_FILTER(TYPE, NAME)     \
  extern "C"                            \
  {                                     \
  ros::GenericFilter* createFilter()    \
  {                                     \
    return new TYPE;                    \
  }                                     \
  class Proxy                           \
  {                                     \
  public:                               \
    Proxy()                             \
    {                                   \
      ros_filter::FilterFactory::add(NAME, createFilter);  \
    }                                   \
  };                                    \
  Proxy p;                              \
  }

#endif /* FILTER_FACTORY_H_ */
