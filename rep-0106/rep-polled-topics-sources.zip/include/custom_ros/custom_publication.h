/*
 * custom_publication.h
 *
 *  Created on: Oct 6, 2010
 *      Author: markus
 */

#ifndef CUSTOM_PUBLICATION_H_
#define CUSTOM_PUBLICATION_H_

#include <ros/publication.h>

#include <string>
#include <map>

using namespace ros;

namespace custom_ros
{

class CustomPublication : public Publication
{
public:
  CustomPublication(const std::string &name,
                    const std::string& datatype,
                    const std::string& _md5sum,
                    const std::string& message_definition,
                    size_t max_queue,
                    bool latch,
                    bool has_header);

  virtual bool enqueueMessage(const SerializedMessage& m);

  virtual void setGenericFilter(const GenericFilterPtr& filter);

private:
  bool passCurrentMessage(const std::string& nodeName);

  std::map<std::string, GenericFilterPtr> filterMap_;

  boost::mutex filter_mutex_;
};

}

#endif /* CUSTOM_PUBLICATION_H_ */
