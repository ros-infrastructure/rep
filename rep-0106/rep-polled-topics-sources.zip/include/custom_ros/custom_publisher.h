/*
 * custom_publisher.h
 *
 *  Created on: Oct 6, 2010
 *      Author: markus
 */

#ifndef CUSTOM_PUBLISHER_H_
#define CUSTOM_PUBLISHER_H_

#include "custom_ros/FilterData.h"

#include <ros/publisher.h>
#include <ros/subscriber.h>

using namespace ros;

namespace custom_ros
{

class CustomPublisher : public Publisher
{
public:
  CustomPublisher(const Publisher& rhs);

  virtual void setupFilter();

private:
  void filterUpdateCallback(const FilterDataConstPtr& msg);

  Subscriber filterSubscriber_;

  Publisher filterPublisher_;
};

}

#endif /* CUSTOM_PUBLISHER_H_ */
