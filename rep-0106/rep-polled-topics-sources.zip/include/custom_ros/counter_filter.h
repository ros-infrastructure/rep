/*
 * custom_filter.h
 *
 *  Created on: Oct 13, 2010
 *      Author: markus
 */

#ifndef CUSTOM_FILTER_H_
#define CUSTOM_FILTER_H_

#include "custom_ros/FilterData.h"

#include <ros/generic_filter.h>

#include <string>

using namespace ros;

namespace custom_ros
{

class CounterFilter : public GenericFilter
{
public:
  static void init();

  CounterFilter();

  //CustomFilter(const CustomFilter& rhs);

  CounterFilter(const std::string& nodeName, int passNumber);

  CounterFilter(const FilterDataConstPtr& filterData);

  //CounterFilter(const std::string& messageString);

  //virtual ~CustomFilter();

  //virtual GenericFilter* clone() const {return new CustomFilter(*this);}

  //virtual FilterData getFilterData() const;

  //virtual std::string createMessage() const;

  virtual bool passCurrentMessage();

private:
  int passNumber_;

  int passCounter_;
};

}

#endif /* CUSTOM_FILTER_H_ */
