/*
 * generic_filter.h
 *
 *  Created on: Oct 13, 2010
 *      Author: markus
 */

#ifndef ROSCPP_GENERIC_FILTER_H_
#define ROSCPP_GENERIC_FILTER_H_

#include <boost/shared_ptr.hpp>
#include <string>

namespace ros
{

class GenericFilter;
typedef boost::shared_ptr<GenericFilter> GenericFilterPtr;

class GenericFilter
{
public:

  GenericFilter()
    : filterType_("GenericFilter")
    , nodeName_("")
    , config_("")
  {}

  GenericFilter(const std::string& nodeName, const std::string& config)
    : filterType_("GenericFilter")
    , nodeName_(nodeName)
    , config_(config)
  {}

//  GenericFilter(const GenericFilter& rhs)
//  {
//    filterType_ = rhs.filterType_;
//    nodeName_ = rhs.nodeName_;
//  }

  //GenericFilter(const std::string& messageString) {}

  virtual ~GenericFilter() {}

  //virtual GenericFilter* clone() const {return new GenericFilter(*this);}

  //virtual std::string createMessage() const {return std::string();}

  virtual const std::string toString() const
  {
    return filterType_ +";"+ nodeName_ +";"+ config_;
  }

  virtual const std::string& getFilterType() const {return filterType_;}

  virtual const std::string& getNodeName() const {return nodeName_;}

  virtual const std::string& getConfig() const {return config_;}

  virtual bool passCurrentMessage() = 0;

protected:
  std::string filterType_;

  std::string nodeName_;

  std::string config_;
};

}

#endif /* ROSCPP_GENERIC_FILTER_H_ */
